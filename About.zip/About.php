<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>
	Cyber-Shiksha Digital Letracy Platform | Home
</title>
	<!-- Meta-tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="keywords" content="Grounding Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,     Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Metga-tags -->

	<!-- Styleshets -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--// Bootstrap-css -->
	<link href="css/easy-responsive-tabs.css" rel="stylesheet" type="text/css" />
	<!--// Responsive-tabs -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<!--// Pop-up -->
	<link href="css/banner.css" rel="stylesheet" type="text/css" media="all" />
	<!--// banner-css -->
	<link rel="stylesheet" href="css/shop.css" type="text/css" media="screen" property="" />
	<!--// shop-css -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- common-css -->
	<link rel="stylesheet" href="css/client.css" type="text/css" media="all" /><link href="css/blog.css" type="text/css" rel="stylesheet" media="all" />
	<!-- // client-css -->
	<link href="css/font-awesome.css" rel="stylesheet" />
</head>
<body>
    <form method="post" action="./Aboutus.aspx" id="form1">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTY1NDU2MTA1MmRk9LDavbFGvUSBbT9BMkULREwg3pV0AtOcg+Q/vyuxn/w=" />

<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="44CCFC92" />

  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>K&T-Group</title>
    <link rel="stylesheet" href="style2.css">
	<link href="https://fonts.googleapis.com/css2?
	family=Poppins:wght@300";400;500;600;700&display=swap"
	rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-
	awesome/4.7.0/css/font-awesome.min.css">
	
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style2.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Permanent+Marker' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Anton' rel='stylesheet' type='text/css'>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
.topnav-right {
  float: right;
}
.header img {
  float: left;
  width: 300px;
  height: 100%;
  background: #555;
}
.col-3{
	background-color:green;
}

</style>
</head>

<body>

<div class="topnav" id="myTopnav" >
<a href="contactus.php"><font color="red"><b>Get In Tuch</b></font></a>
<div class="topnav-right">
<a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
	
  <a href="index.php"class="active">Home |</a>
  <a href="About.php">About |</a>
  <a href="Account.php">All Courses |</a>
  <a href="LCL.php">Local Chaptor |</a>
  <a href="feedback.php">feedback </a>
  <div style="padding-left:16px">

  </a>
  </div>
</div>
</div>
</div>
		<div class="header-middle">
			<div class="container">
				<div class="logof-w3-agile">
					<img src="img/clogo.png" />
				</div>
				
			
				<div class="clearfix"></div>
			</div>
		</div>
		<!--// header-middle -->
		<nav class="navbar navbar-inverse">
			<div class="navbar-header">
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
			</div>
<div class="topnav-right">
			<div class="collapse navbar-collapse js-navbar-collapse">
            <div class="container">
			
				<ul class="nav navbar-nav">
	
				</ul>
                </div>
			</div></div>
			<!-- /.nav-collapse -->
		</nav>

	</div>
	<div>
        
<div class="abtbanner"><img src="images/abt.jpg" /></div>
	<!--//banner -->
	<!-- about -->
	<div class="aboutf">
		<div class="container">
			<h3 class="tittlef-agileits-w3layouts">About Us<span class="line"></span></h3>

            <p class="abtp">Cyber Security Skills Development and Enabling Growth Opportunities to Women Talent in cyber security domain is a key imperative for Government and Industry. DSCI is pleased to partner with Microsoft in developing industry ready women cyber security professionals though Cyber Shikshaa program. </p>
                        <p class="abtp">Microsoft & Data Security Council of India (DSCI) with support from ISEA an initiative of Ministry of Electronics & IT (MeitY) have launched Project Cyber Shikshaa for skilling women engineering graduates in the niche field of Cyber Security in September 2018.</p>
                        <p class="abtp">This endeavour has trained over 800 young women engineers across India in cybersecurity. The training program has spanned across 22 batches from 13 cities across 11 states in classroom mode, blended and fully virtual mode. </p>
                        <p class="abtp">CyberShikshaa students being placed successfully in global corporations, large technology services firms, start-ups and even law enforcement agencies is a highly satisfying outcome. </p>
                        <p class="abtp">Since its inception, CyberShikshaa was designed to bring attention to bridge the diversity gap in the cybersecurity workforce. </p>
<p class="abtp">During the pandemic, with support from all our training partners, we were able to quickly pivot and smoothly transition to a fully online mode, which also broadened the access to this training program to young women from tier-III/tier-IV cities.</p>
			
        </div>
		
	</div>
	<!-- //about-->

    	<!-- blog -->
	<div class="blog main-pos demo-sec" id="blog">
	
		<div class="container">
			<div class="blog-sub">
				<div class="col-md-12 blog-sp">
               					
						<div class="col-md-12" style="background-color: #FFFF99; height: 50px;">
							
								<h3 class="tittlef-agileits-w3layouts"><a href="Legal.aspx">View Legal</a><span class="line"></span></h3>
							
						</div>
						<div class="clearfix"></div>
					<div class="blog-x br-mar">
						<div class="col-md-4 blog-w3-agile-img">
							 
								<img src="images/mision.jpg" alt="" class="img-responsive" />
							 
						</div>
						<div class="col-md-8 blog_w3_info1">
							<h5>
								OUR MISSION
							</h5>
						
							<p class="vison">There has been a steep rise in the demand for skilled workforce in this domain and representation of women in the Cyber Security workforce has been low compared to that of the overall IT industry average. Cyber Shikshaa intends to bridge the gap between the demand and supply of talented professionals as well as enhance the number of women working in the field of Cyber Security.</p>
							
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="blog-x br-mar">
						<div class="col-md-8 blog_w3_info1">
							<h5>
								OUR VISION
							</h5>
							
                        <p class="vison">
                        Microsoft & Data Security Council of India (DSCI) with support from ISEA an initiative of Ministry of Electronics & IT (MeitY) have launched Project Cyber Shikshaa for skilling women engineering graduates in the niche field of Cyber Security in September 2018. The training program has spanned across 22 batches from 13 cities across 11 states in classroom mode, blended and fully virtual mode.</p>
					 
						</div>
						<div class="col-md-4 blog-w3-agile-img img1">
						 
								<img src="images/vision.jpg" alt="" class="img-responsive" />
							 
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				
				<div class="clearfix"></div>
			</div>
			
		</div>
	</div>
	<!-- //blog -->

    </div>

	<!-- footer -->
	<div class="footer_agileinfo_topf">
		<div class="container">
		 
			<div class="col-md-4 footer_w3layouts_gridf">
            <h1 class="footerLinkh1">Navigation</h1>
				<nav>
					<ul class="footer_w3layouts_gridf_list">
						<li><span class="fa fa-angle-right" aria-hidden="true"></span>
							<a href="Default.aspx">Home</a>
						</li>
						<li><span class="fa fa-angle-right" aria-hidden="true"></span>
							<a href="Aboutus.aspx">About Us</a>
						</li>
                        <li><span class="fa fa-angle-right" aria-hidden="true"></span>
							<a href="Legal.aspx">Legal</a>
						</li>
						<li><span class="fa fa-angle-right" aria-hidden="true"></span>
							<a href="businessplan.aspx"> How It Works</a>
						</li>						

                        <li><span class="fa fa-angle-right" aria-hidden="true"></span>
							<a href="Rewards.aspx">Rewards</a>
						</li>

                         <li><span class="fa fa-angle-right" aria-hidden="true"></span>
							<a href="contactus.aspx"> Contact Us</a>
						</li>

                       
					</ul>
				</nav>
			</div>
			<div class="col-md-4 footer_w3layouts_gridf">
			 <h1 class="footerLinkh1">About Us</h1>
             <p class="footerp">Cyber Security Skills Development and Enabling Growth Opportunities to Women Talent in cyber security domain is a key imperative for Government and Industry. DSCI is pleased to partner with  </p>
           <p class="footerp"> Microsoft in developing industry ready women cyber security professionals though Cyber Shikshaa program.As India leapfrogs into the next phase of growth, we see a multi-fold growth of digital assets.  </p>
             <p class="footerp"><a href="#">Read More ..</a></p>
			</div>

            <div class="col-md-4 footer_w3layouts_gridf">
			<h1 class="footerLinkh1">Portfolio</h1>

            <ul class="footerportfolio">
            <li><img src="images/1.png" /></li>
             <li><img src="images/2.png" /></li>
              <li><img src="images/3.png" /></li>
               <li><img src="images/4.png" /></li>
                  <li><img src="images/1.png" /></li>
             <li><img src="images/2.png" /></li>
              <li><img src="images/3.png" /></li>
               <li><img src="images/4.png" /></li>
                <li><img src="images/1.png" /></li>
             <li><img src="images/2.png" /></li>
              <li><img src="images/3.png" /></li>
               <li><img src="images/4.png" /></li>
                 <li><img src="images/2.png" /></li>
              <li><img src="images/3.png" /></li>
               <li><img src="images/4.png" /></li>
            
            </ul>

			</div>
			<div class="clearfix"> </div>
			<div class="w3ls-fsocial-grid">
				<h3 class="sub-w3ls-headf">Follow Us</h3>
				<div class="social-ficons">
					<ul>
						<li><a href="#"><span class="fa fa-facebook"></span> Facebook</a></li>
						<li><a href="#"><span class="fa fa-twitter"></span> Twitter</a></li>
						<li><a href="#"><span class="fa fa-google"></span>Google</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-wthree-copyf">
		<div class="container">
		 
			<p class="copyrihgt">Copyright 2023 - Cyber-Shiksha - || - <b>Powered By</b>:- <font color="red"><b>K&T-Group</p></b></font>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //footer -->

	<!-- js -->

	<!-- Common js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<!--// Common js -->

	<!-- cart-js -->
	<script src="js/minicart.js"></script>


      <script type="text/javascript">
          $(document).ready(function () {
              $("#myModal").modal('show');
          });
</script>


	<script>
	    edu.render();

	    edu.cart.on('edu_checkout', function (evt) {
	        var items, len, i;

	        if (this.subtotal() > 0) {
	            items = this.items();

	            for (i = 0, len = items.length; i < len; i++) { }
	        }
	    });
	</script>
	<!-- //cart-js -->

	<!-- reviews -->
	<script>
	    function blinker() {
	        $('.blinking').fadeOut(500);
	        $('.blinking').fadeIn(500);
	    }
	    setInterval(blinker, 1000);
	</script>
	<script>
	    function cycle($item, $cycler) {
	        setTimeout(cycle, 2000, $item.next(), $cycler);

	        $item.slideUp(1000, function () {
	            $item.appendTo($cycler).show();
	        });
	    }
	    cycle($('#cycler div:first'), $('#cycler'));
	</script>
	<!--// reviews -->

	<!-- responsive-tabs -->
	<script src="js/easy-responsive-tabs.js"></script>
	<script>
	    $(document).ready(function () {
	        $('#verticalTab').easyResponsiveTabs({
	            type: 'vertical',
	            width: 'auto',
	            fit: true
	        });
	    });
	</script>
	<!-- //responsive-tabs -->

	<!-- Carousel Auto-Cycle -->
	<script>
	    $(document).ready(function () {
	        $('.carousel').carousel({
	            interval: 6000
	        })
	    });
	</script>
	<!-- // Carousel Auto-Cycle -->

	<!-- Nav Js -->
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script>
	    $(document).ready(function () {
	        $(".dropdown").hover(
				function () {
				    $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true, true).slideDown("400");
				    $(this).toggleClass('open');
				},
				function () {
				    $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true, true).slideUp("400");
				    $(this).toggleClass('open');
				}
			);
	    });
	</script>
	<!--// Nav Js -->


	<script>
	    $('.toggle').click(function () {
	        // Switches the Icon
	        $(this).children('i').toggleClass('fa-pencil');
	        // Switches the forms  
	        $('.form').animate({
	            height: "toggle",
	            'padding-top': 'toggle',
	            'padding-bottom': 'toggle',
	            opacity: "toggle"
	        }, "slow");
	    });
	</script>
	<!-- //bootstrap-pop-up -->

	<!--pop-up-box -->
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	<script>
	    $(document).ready(function () {
	        $('.popup-with-zoom-anim').magnificPopup({
	            type: 'inline',
	            fixedContentPos: false,
	            fixedBgPos: true,
	            overflowY: 'auto',
	            closeBtnInside: true,
	            preloader: false,
	            midClick: true,
	            removalDelay: 300,
	            mainClass: 'my-mfp-zoom-in'
	        });

	    });
	</script>
	<!-- //pop-up-box -->
	<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
	    jQuery(document).ready(function ($) {
	        $(".scroll").click(function (event) {
	            event.preventDefault();
	            $('html,body').animate({
	                scrollTop: $(this.hash).offset().top
	            }, 1000);
	        });
	    });
	</script>
	<!-- start-smoth-scrolling -->
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
	    $(document).ready(function () {
	        /*
	        var defaults = {
	        containerID: 'toTop', // fading element id
	        containerHoverID: 'toTopHover', // fading element hover id
	        scrollSpeed: 1200,
	        easingType: 'linear' 
	        };
	        */

	        $().UItoTop({
	            easingType: 'easeOutQuart'
	        });

	    });
	</script>
	<!-- //here ends scrolling icon -->
	<!-- smoothscroll -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smoothscroll -->
    <script type="text/javascript">
        //    jQuery(window).load(function() {
        jQuery(function () {
            var myCamera = jQuery('#camera5448d07be94d1');
            if (!myCamera.hasClass('motopress-camera')) {
                myCamera.addClass('motopress-camera');
                myCamera.camera({
                    alignment: 'topCenter', //topLeft, topCenter, topRight, centerLeft, center, centerRight, bottomLeft, bottomCenter, bottomRight
                    autoAdvance: true, //true, false
                    mobileAutoAdvance: true, //true, false. Auto-advancing for mobile devices
                    barDirection: 'leftToRight', //'leftToRight', 'rightToLeft', 'topToBottom', 'bottomToTop'
                    barPosition: 'top', //'bottom', 'left', 'top', 'right'
                    cols: 12,
                    easing: 'easeOutQuad', //for the complete list http://jqueryui.com/demos/effect/easing.html
                    mobileEasing: '', //leave empty if you want to display the same easing on mobile devices and on desktop etc.
                    fx: 'random', //'random','simpleFade', 'curtainTopLeft', 'curtainTopRight', 'curtainBottomLeft',          'curtainBottomRight', 'curtainSliceLeft', 'curtainSliceRight', 'blindCurtainTopLeft', 'blindCurtainTopRight', 'blindCurtainBottomLeft', 'blindCurtainBottomRight', 'blindCurtainSliceBottom', 'blindCurtainSliceTop', 'stampede', 'mosaic', 'mosaicReverse', 'mosaicRandom', 'mosaicSpiral', 'mosaicSpiralReverse', 'topLeftBottomRight', 'bottomRightTopLeft', 'bottomLeftTopRight', 'bottomLeftTopRight'
                    //you can also use more than one effect, just separate them with commas: 'simpleFade, scrollRight, scrollBottom'
                    mobileFx: '', //leave empty if you want to display the same effect on mobile devices and on desktop etc.
                    gridDifference: 250, //to make the grid blocks slower than the slices, this value must be smaller than transPeriod
                    height: '52.5%', //here you can type pixels (for instance '300px'), a percentage (relative to the width of the slideshow, for instance '50%') or 'auto'
                    imagePath: 'images/camera-slider/', //he path to the image folder (it serves for the blank.gif, when you want to display videos)
                    loader: 'no', //pie, bar, none (even if you choose "pie", old browsers like IE8- can't display it... they will display always a loading bar)
                    loaderColor: '#ffffff',
                    loaderBgColor: '#eb8a7c',
                    loaderOpacity: 1, //0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1
                    loaderPadding: 0, //how many empty pixels you want to display between the loader and its background
                    loaderStroke: 3, //the thickness both of the pie loader and of the bar loader. Remember: for the pie, the loader thickness must be less than a half of the pie diameter
                    minHeight: '147px', //you can also leave it blank
                    navigation: true, //true or false, to display or not the navigation buttons
                    navigationHover: false, //if true the navigation button (prev, next and play/stop buttons) will be visible on hover state only, if false they will be visible always
                    pagination: true,
                    playPause: false, //true or false, to display or not the play/pause buttons
                    pieDiameter: 33,
                    piePosition: 'rightTop', //'rightTop', 'leftTop', 'leftBottom', 'rightBottom'
                    portrait: true, //true, false. Select true if you don't want that your images are cropped
                    rows: 8,
                    slicedCols: 12,
                    slicedRows: 8,
                    thumbnails: false,
                    time: 5000, //milliseconds between the end of the sliding effect and the start of the next one
                    transPeriod: 1200, //lenght of the sliding effect in milliseconds

                    ////////callbacks

                    onEndTransition: function () { }, //this callback is invoked when the transition effect ends
                    onLoaded: function () { }, //this callback is invoked when the image on a slide has completely loaded
                    onStartLoading: function () { }, //this callback is invoked when the image on a slide start loading
                    onStartTransition: function () { } //this callback is invoked when the transition effect starts
                });
            }
        });
        //    });
	
</script>
   
        <script>
            $(document).ready(function () {
                $('#popupBG').fadeIn(1000, function () {
                    $("#popUp").fadeIn(100)
                    $("body").css("overflow", "hidden");

                });

                $('#closePOp').click(function () {
                    $("#popUp").fadeOut(100);
                    $("#popupBG").fadeOut(200);
                    $("body").css("overflow", "auto");
                });
                $('#popupBG').click(function () {
                    $("#popUp").fadeOut(100);
                    $("#popupBG").fadeOut(200);
                    $("body").css("overflow", "auto");
                });

            });
    </script>
    </form>
</body>
</html>
